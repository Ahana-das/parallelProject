package com.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cap.bean.BankDetail;
import com.cap.service.BankService;
import com.cap.service.BankServiceImp;

public class BankDaoImp implements BankDao {
	
	//BankService service1=new BankServiceImp();

	@Override
	public long insertBankDetails(BankDetail bank) {
		Connection conn;
		long value = 0;
		try {
			conn=DBConnect.getConnection();
			PreparedStatement stmt = conn.prepareStatement("insert into BankAccount values(?,?,?,?,AccountSeq.nextVal,?)");
			stmt.setString(1, bank.getName());
			stmt.setString(2, bank.getBranch());
			stmt.setLong(3, bank.getMobileno());
			stmt.setString(4, bank.getAccountType());
			stmt.setLong(5, bank.getBalance());
			int val=stmt.executeUpdate();
			if(val>0)
			{
				PreparedStatement stmt1 = conn.prepareStatement("select AccountSeq.currval from dual");
				ResultSet val1=stmt1.executeQuery();
				val1.next();
				 value=val1.getLong(1);
				System.out.println("Account Created Succesfully");
				
			}
		} catch (SQLException ae) {
			System.out.println(ae);
		}
		return value;
	}

	@Override
	public long showBalance(long accountno) {
		Connection conn;
		long value=0;
		try{
			conn=DBConnect.getConnection();
			PreparedStatement stmt1 = conn.prepareStatement("select balance from BankAccount where accountno=?");
			stmt1.setLong(1, accountno);
			ResultSet val1=stmt1.executeQuery();
			
			
			val1.next();
			 value=val1.getLong(1);
			
			
		}catch (Exception ae) {
			System.out.println(ae);
		}
		return value;
	}

	@Override
	public int depositMoney(long accountno, int depositAmount) {
		Connection conn;
		long deposit=0;
		long result1=0;
		
		try{
			
			conn=DBConnect.getConnection();
			PreparedStatement stmnt = conn.prepareStatement("select balance from BankAccount where accountno=?");
			stmnt.setLong(1, accountno);
			ResultSet set=stmnt.executeQuery();
			set.next();
			
			long	prebal = set.getLong(1);
			deposit=prebal + depositAmount;
			PreparedStatement stmnt1 = conn.prepareStatement("update BankAccount set balance=? where accountno=?");
			
			
			

			stmnt1.setLong(1, deposit);
			stmnt1.setLong(2, accountno);
			result1=stmnt1.executeUpdate();
			
			String s="deposit";
			long fromAccount=00000;
			PreparedStatement stmnt2 = conn.prepareStatement("insert into BankTransaction values(TransSeq.nextval,?,?,?,?,?)");
			stmnt2.setLong(1,fromAccount);
			stmnt2.setLong(2,accountno);
			stmnt2.setLong(3,prebal);
			stmnt2.setLong(4,deposit);
			stmnt2.setString(5,s);
			
			stmnt2.executeUpdate();
			
			
			
			
		}catch (Exception ae) {
			System.out.println(ae);
		}
		if(result1>0)
		{	return (int) deposit;
		
		}
		return 0;
	}

	@Override
	public int withdrawMoney(long accountno, int withdrawAmount) {
		Connection conn;
		long withdraw=0;
		long result1=0;
		
		try{
			conn=DBConnect.getConnection();
			PreparedStatement stmnt = conn.prepareStatement("select balance from BankAccount where accountno=?");
			stmnt.setLong(1, accountno);
			ResultSet set=stmnt.executeQuery();
			set.next();
		
			long	prebal = set.getLong(1);
			withdraw=prebal - withdrawAmount;
			PreparedStatement stmnt1 = conn.prepareStatement("update BankAccount set balance=? where accountno=?");
			
			
			

			stmnt1.setLong(1, withdraw);
			stmnt1.setLong(2, accountno);
			result1=stmnt1.executeUpdate();
			

			String s="withdraw";
			long toAccount=00000;
			
			PreparedStatement stmnt2 = conn.prepareStatement("insert into BankTransaction values(TransSeq.nextval,?,?,?,?,?)");
			
			stmnt2.setLong(1,accountno);
			stmnt2.setLong(2,toAccount);
			stmnt2.setLong(3,prebal);
			stmnt2.setLong(4,withdraw);
			stmnt2.setString(5,s);
			
			stmnt2.executeUpdate();
			
			
		}catch (Exception ae) {
			System.out.println(ae);
		}
		if(result1>0)
		{	return (int) withdraw;
		
		}
		return 0;
	}


	@Override
	public long transferFunds(long firstAcc, long secondAcc, int transferAmount) {
		Connection conn;
		long updatebal=0;
		
		
		try{
			conn=DBConnect.getConnection();
			PreparedStatement stmnt = conn.prepareStatement("select balance from BankAccount where accountno=?");
			stmnt.setLong(1, firstAcc);
			ResultSet set=stmnt.executeQuery();
			set.next();
			long	firstbal = set.getLong(1);
			
			PreparedStatement stmnt1 = conn.prepareStatement("select balance from BankAccount where accountno=?");
			stmnt1.setLong(1, secondAcc);
			ResultSet set1=stmnt1.executeQuery();
			set1.next();
			long secondbal = set1.getLong(1);
			
			
			updatebal=firstbal - transferAmount;
			long updatebal1=secondbal+transferAmount;
			PreparedStatement stmnt2 = conn.prepareStatement("update BankAccount set balance=? where accountno=?");
			stmnt2.setLong(1, updatebal);
			stmnt2.setLong(2, firstAcc);
			
			int result2=stmnt2.executeUpdate();
			

			
			
			PreparedStatement stmnt3 = conn.prepareStatement("update BankAccount set balance=? where accountno=?");
			stmnt3.setLong(1, updatebal1);
			stmnt3.setLong(2, secondAcc);
			
			int result3=stmnt3.executeUpdate();
			
			
			String s1="Fundtransfer";
			
			
			PreparedStatement stmnt6 = conn.prepareStatement("insert into BankTransaction values(TransSeq.nextval,?,?,?,?,?)");
			
			stmnt6.setLong(1,firstAcc);
			stmnt6.setLong(2,secondAcc);
			stmnt6.setLong(3,firstbal);
			stmnt6.setLong(4,updatebal);
			stmnt6.setString(5,s1);
			
			stmnt6.executeUpdate();
			
			
			}catch (Exception ae)
		{
			ae.printStackTrace();
			}
		
		return updatebal;
	}

	@Override
	public long printTransaction() {
		   System.out.println(
	                "===============================================================================================================");
	        System.out.println(
	                "Tran  Id     From Account      To Account     Old Balance         New Balance          Trans Type    ");
	        System.out.println(
	                "===============================================================================================================");
	        Connection conn =DBConnect.getConnection();
	        PreparedStatement p2;
	        ResultSet r;
	            try {
	                p2 = conn.prepareStatement("select * from BankTransaction");
	                r=p2.executeQuery();
	                while (r.next()) {
	                    System.out.println(r.getInt(1) + "           " + r.getLong(2) + "           "+ r.getLong(3) + "            " + r.getLong(4) + "             "+r.getLong(5) + "            " + r.getString(6) + "               ");
	                
	            } 
	            }
	                catch (SQLException e) {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            }
	            return 0;
	        

	 

	            }
	
}
