package com.cap.dao;

import org.junit.Assert;
import org.junit.Test;

import com.cap.bean.BankDetail;

public class BankDaoImpJunit {
	BankDaoImp dao = new BankDaoImp();

	@Test
	public void createBankAccount() {
	BankDetail bank = new BankDetail();
		bank.setMobileno( 9674616130l);
		bank.setBalance(2000);
		bank.setAccountType("savings");
		bank.setAccountno(10410);
		bank.setName("shubham");
		bank.setBranch("kolkata");
		
	long acc=dao.showBalance(10410);
	Assert.assertEquals(2000, acc);;
	
}
	@Test
	public void createBankAccount1() {
	BankDetail bank = new BankDetail();
		bank.setMobileno( 9674616130l);
		bank.setBalance(2000);
		bank.setAccountType("savings");
		bank.setAccountno(10410);
		bank.setName("shubham");
		bank.setBranch("kolkata");
		
	long acc1=dao.showBalance(10410);
	Assert.assertEquals(1000, acc1);;
	
}
}
