package com.cap.dao;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.cap.bean.BankDetail;

public class BankDaoImpJunit {
	BankDaoImp dao = new BankDaoImp();

	@Test
		public void createBankAccount() {
		BankDetail bank = new BankDetail();
			bank.setMobileno(8697459468l);
			bank.setBalance(200);
			bank.setAccountno(5580002);
			bank.setName("ahana");
			bank.setBranch("kolkata");
			
		long acc = dao.insertBankDetails(bank);
		Assert.assertEquals(5580002, acc);;
	}
	 @Test
	 public void createBankAccount1() {
			BankDetail bank = new BankDetail();
				bank.setMobileno(8697459468l);
				bank.setBalance(200);
				bank.setAccountno(5580002);
				bank.setName("ahana");
				bank.setBranch("kolkata");
				
			long acc = dao.insertBankDetails(bank);
			Assert.assertEquals(5580000, acc);;
	 
}
}
