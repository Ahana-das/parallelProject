package com.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cap.bean.BankDetail;
import com.cap.bean.BankTransaction;

@Repository
public class BankDaoImp implements BankDao {
	
	@PersistenceContext
	private EntityManager entityManager;
		
		

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Transactional
	@Override
	public long insertBankDetails(BankDetail bank) {
		entityManager.persist(bank);
		return bank.getAccountno();
		
		
	}

	@Transactional
	@Override
	public BankDetail showBalance(long accountno) {
		BankDetail bank = entityManager.find(BankDetail.class, accountno);
		return bank;
	}

	@Transactional
	@Override
	public long depositMoney(long accountno, int depositAmount) {
		BankDetail acc = entityManager.find(BankDetail.class, accountno);
		long oldBal= acc.getBalance();
		long newBal= oldBal + depositAmount;
		acc.setBalance(newBal);
		entityManager.merge(acc);
		
		BankTransaction transaction =new  BankTransaction();
        transaction.setToAccount(accountno);;
        transaction.setNewBalance(newBal);;
        transaction.setOldBalance(oldBal);
        transaction.setTranstype("Credit");
        entityManager.persist(transaction);
		
		return newBal;
		
	}

	@Transactional
	@Override
	public long withdrawMoney(long accountno, int withdrawAmount) {
		BankDetail acc = entityManager.find(BankDetail.class, accountno);
		long oldBal= acc.getBalance();
		long newBal= oldBal - withdrawAmount;
		acc.setBalance(newBal);
		entityManager.merge(acc);
		
		BankTransaction transaction =new  BankTransaction();
        transaction.setFromAccount(accountno);;
        transaction.setNewBalance(newBal);;
        transaction.setOldBalance(oldBal);
        transaction.setTranstype("Debit");
        entityManager.persist(transaction);
		
		
		return newBal;
	}


	@Transactional
	@Override
	public long transferFunds(long firstAcc, long secondAcc, int transferAmount) {
		BankDetail acc = entityManager.find(BankDetail.class, firstAcc);
		long oldBal= acc.getBalance();
		long newBal= oldBal - transferAmount;
		acc.setBalance(newBal);
		entityManager.merge(acc);
		
		BankDetail acc1 = entityManager.find(BankDetail.class, secondAcc);
		long oldBal1= acc1.getBalance();
		long newBal1= oldBal1 + transferAmount;
		acc1.setBalance(newBal1);
		entityManager.merge(acc1);
		
		
		BankTransaction transaction =new  BankTransaction();
        transaction.setFromAccount(firstAcc);;
        transaction.setToAccount(secondAcc);;
        transaction.setOldBalance(oldBal);;
        transaction.setNewBalance(newBal);;
        transaction.setTranstype("Fund Transfer");
        entityManager.persist(transaction);
		
		return newBal;
		
	}

	@Override
	
		public List<BankTransaction> printTransaction() {
	        // TODO Auto-generated method stub
	        TypedQuery<BankTransaction> q2=entityManager.createQuery("select c from BankTransaction c",BankTransaction.class);
	        List<BankTransaction> l1=q2.getResultList();
	        return l1;
	    }
	            

	
	
}
