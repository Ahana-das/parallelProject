package com.cap.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class BankTransaction {
	@Id
	@GeneratedValue
	private int tid;
	private long fromAccount;
	private long toAccount;
	private long oldBalance;
	private long newBalance;
	private String transtype;

	@Override
	public String toString() {
		return  tid + ",\t " + fromAccount + ",\t " + toAccount
				+ ",\t " + oldBalance + ",\t " + newBalance + ",\t " + transtype + "]";
	}

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public long getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(long fromAccount) {
		this.fromAccount = fromAccount;
	}

	public long getToAccount() {
		return toAccount;
	}

	public void setToAccount(long toAccount) {
		this.toAccount = toAccount;
	}

	public long getOldBalance() {
		return oldBalance;
	}

	public void setOldBalance(double prevBal) {
		this.oldBalance = (long) prevBal;
	}

	public long getNewBalance() {
		return newBalance;
	}

	public void setNewBalance(double remainingBal) {
		this.newBalance = (long) remainingBal;
	}

	public String getTranstype() {
		return transtype;
	}

	public void setTranstype(String transtype) {
		this.transtype = transtype;
	}

}